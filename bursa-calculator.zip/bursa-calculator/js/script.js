$(document).ready(function() {
    fullHeight();
    rangePosition();
});

$(window).on('load', function() {
    rangePosition();
});

$(window).on('resize', function() {
    fullHeight();
});



jQuery(".ag-calculator_input-wrap").on('click', function() {
    rangePosition();
});



function fullHeight() {

     if ($(window).outerWidth() > 991) {

        var full_height = jQuery(window).innerHeight();

        jQuery('.full-height').css({
          'min-height' : full_height,
        });

    }

}



function rangePosition() {
            
    var rangeFirstPosition = jQuery('.form__calculator-first-range .rangeslider__handle').attr('style');
    jQuery('.form__calculator-first-range .range-circle').attr('style', rangeFirstPosition);

    var rangeSecondPosition = jQuery('.form__calculator-second-range .rangeslider__handle').attr('style');
    jQuery('.form__calculator-second-range .range-circle').attr('style', rangeSecondPosition);

}

function getParamFromString (link, name) {
    var result;
    var urlRegex = new RegExp(name + '=([^&]+)', 'm');
    var match = urlRegex.exec(location.href);
    if (match !== null) {
      result = match[1];
    } else {
      result = '';
    }

    return result;
}




(function ($) {

    //console.log('js/script.js loaded');
		var leadUrl = 'https://lp.xnes.co.il/360/leads/backup_lead.php'; //Staging
    var formSubmitted = false;

    jQuery('#pc-form').submit(function(e){
        e.preventDefault();
        if (formSubmitted) return;
        formSubmitted = true;
        var data = {};
        data['campaignId'] = '05381CB2-7B69-4EE6-A275-B78E4593EA0C';
        data['lead'] = [];

        data['lead'][0] = {"type":"full_name","name":"full_name","value":jQuery(this).find('[name=full_name]').val()};
        data['lead'][1] = {"type":"phone","name":"phone","value":jQuery(this).find('[name=phone]').val()};
        data['lead'][2] = {"type":"email","name":"email","value":jQuery(this).find('[name=email]').val()};

        //data['media'] = jQuery(this).find('[name=media]').val();
        data['media'] = jQuery(window).width() > 992 ? "Desktop" : "Mobile";
        // data['full_name'] = jQuery(this).find('[name=full_name]').val();
        // data['phone'] = jQuery(this).find('[name=phone]').val();
        // data['email'] = jQuery(this).find('[name=email]').val();
        data['camp'] = getParamFromString(location.href, 'utm_campaign');
        data['source'] = getParamFromString(location.href, 'utm_source');
        //New field added
        data['utm_source'] = getParamFromString(location.href, "utm_source");
        data['utm_campaign'] = getParamFromString(location.href, "campaign");
        //data['category'] = jQuery(this).find('[name=category]').val();
        data['category'] = 'Test';    
        if(jQuery(this).find('input[type="checkbox"]').is(':checked')){
            data['newsletter'] = 1;
        }else{
            data['newsletter'] = 0;
        }
        data['leadUrl'] = window.location.protocol + '//' + window.location.host + window.location.pathname
        //data['ga'] = GA;//You did this at Yaris campaign, same technique.
        data['gclid'] = getParamFromString(location.href, "gclid");
        data['term'] = getParamFromString(location.href, "term");
        data['content'] = getParamFromString(location.href, "content");
        data['utm_medium'] = getParamFromString(location.href, "utm_medium");

        /**
         * Post lead to new crm Lead.im
         */
        data["lm_source"] = window.location.href;
        data["utm_source"] = getParamFromString(location.href, "utm_source");
        data["utm_medium"] = getParamFromString(location.href, "utm_medium");
        data["utm_campaign"] = getParamFromString(location.href, "utm_campaign");
        data["utm_term"] = getParamFromString(location.href, "utm_term");
        data["utm_content"] = getParamFromString(location.href, "utm_content");
        data["url"] = window.location.pathname;
        data["device"] = window.innerWidth > 992 ? "Desktop" : "Mobile";
        data["lm_serfer_ga_cid"] = Date.now();

        data['keyword'] = getParamFromString(location.href, "keyword");
        data['campaignID'] = getParamFromString(location.href, "campaignID");
        data['matchtype'] = getParamFromString(location.href, "matchtype");
        data['adgroupID'] = getParamFromString(location.href, "adgroupID");

        jQuery.ajax({
            url: leadUrl,
            method: 'POST',
            data: JSON.stringify(data)
        })
        .done(function(){
						// jQuery('#pc-form').hide();
						// jQuery('.thank-you-message').show();
						window.location.href = 'success.html'
        });
    });		

    $(function () {

        $("input[type=range][name=file-value]").rangeslider({
            polyfill: false,
        });
        $("input[type=range][name=monthly-prescripts]").rangeslider({
            polyfill: false,
        });


        let t = $("#file-value"),
            e = $("#monthly-prescripts"),
            l = $("#bank-fees"),
            x = $("#xnes-fees"),
            z = $("#result-fees");
            /*u = $(".tab-pane.active").attr("id"),*/

        function agFormula() {
            /*
            ((File_Value)*(Foreign_Portfolio)*(Foreign_Fees)+(File_Value)*(Israelian_Portfolio)*(Israelian_Fees))+
            ((Monthly_Prescripts)*(Foreign_Portfolio)*(Average_Foreign_Fees)*12)+((Monthly_Prescripts)*(Israelian_Portfolio)*(Average_Israelian_Fees)*12)
             */
            let average_bursa_prescript = 4000;
            let foreign_porfolio = .70;
            let israelian_portfolio = .30;
            let average_israelian_fees = 20;
            let average_foreign_fees = 68;
            let xnes_foreign_securities = 17;
            let monthly_prescripts = e.val();

            //file-value
            let file_value = parseInt(t.val());
            // dynamic depends file-value
            let israelian_fees = .00290;
            let foreign_fees = .00283;
            let israelian_securities = .000944;

            if(file_value === 25000){
                israelian_fees = .00290;
                foreign_fees = .00283;
                israelian_securities = .000944;
            }
            if(file_value === 50000){
                israelian_fees = .00380;
                foreign_fees = .00316;
                israelian_securities = .000912;
            }
            if(file_value === 75000){
                israelian_fees = .00362;
                foreign_fees = .00311;
                israelian_securities = .000958;
            }
            if(file_value === 100000){
                israelian_fees = .00357;
                foreign_fees = .00390;
                israelian_securities = .000914;
            }
            if(file_value >= 125000 && file_value <= 200000 ){
                israelian_fees = .00325;
                foreign_fees = .00301;
                israelian_securities = .000980;
            }
            if(file_value >= 225000 && file_value <= 375000 ){
                israelian_fees = .00302;
                foreign_fees = .00282;
                israelian_securities = .000861;
            }
            if(file_value >= 400000 && file_value <= 675000 ){
                israelian_fees = .00252;
                foreign_fees = .00295;
                israelian_securities = .000800;
            }
            if(file_value >= 700000 && file_value <= 1025000 ){
                israelian_fees = .00221;
                foreign_fees = .00242;
                israelian_securities = .000753;
            }
            if(file_value >= 1050000 && file_value <= 1500000 ){
                israelian_fees = .00131;
                foreign_fees = .00153;
                israelian_securities = .000784;
            }
            //console.log("file_value:"+file_value,"monthly_prescripts:"+monthly_prescripts,"israelian_fees:"+israelian_fees, "foreign_fees:"+foreign_fees, "israelian_securities:"+israelian_securities);

            let bankfees = parseFloat(
                (file_value * israelian_portfolio * israelian_fees + file_value * foreign_porfolio * foreign_fees)
                + ( monthly_prescripts * foreign_porfolio * average_foreign_fees * 12 ) + (monthly_prescripts * israelian_portfolio * average_israelian_fees * 12) ).toFixed(2);
            l.html("Bank fees:"+bankfees).digits();
            $('.range-count.file-value').html(file_value).digits();
            //console.log("Bank fees:" + bankfees);

            let xnesfees = parseFloat(
                (average_bursa_prescript * monthly_prescripts * israelian_portfolio * israelian_securities * 12)
                + (monthly_prescripts * foreign_porfolio * xnes_foreign_securities * 12) ).toFixed(2);
            x.html("XNES fees:"+xnesfees).digits();
            $('.range-count.monthly-prescripts').html(monthly_prescripts).digits();

            if(file_value === 25000 && monthly_prescripts == 1){
                xnesfees = 228;
            }
            //console.log("XNES fees:" + xnesfees);

            //$('.form__calculator--js-output--price').html((bankfees - xnesfees).toFixed(2)).digitsComma();
            $('.form__calculator--js-output--price').html(bankfees).digitsComma();
            $('.form__calculator-output--price').html(xnesfees).digitsComma();
            $('.form__calculator--bottom-result span').html((bankfees - xnesfees).toFixed(2)).digitsComma();
        }

        $(".js-calculator_input-wrap > .js-calculator_text-input").on("change input", function () {
            $(this).parent().find(".js-calculator_range").val($(this).val()).change();

            agFormula();
        });

        $(".js-calculator_input-wrap > .js-calculator_range").on("change input", function () {
            $(this).parent().find(".js-calculator_text-input").val($(this).val());
            /*if($(this).val() == 2){
                console.log($(this).val());
            }*/

            agFormula();
        });

        $(".js-calculator_input-wrap > .js-calculator_radio-box > .js-calculator_radio").on("change input", function () {
            agFormula();
        });

        $.fn.digits = function () {
            return this.each(function () {
                $(this).text($(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1 "));
            });
        };
        $.fn.digitsComma = function () {
            return this.each(function () {
                $(this).text($(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            });
        };

        agFormula();

    });
})(jQuery);

document.addEventListener("DOMContentLoaded", function(event) {
    // for new leam.im start
    function getParamFromString( link, name ) {
        let result;
        let urlRegex = new RegExp( name + '=([^&]+)', 'm' );
        let match = urlRegex.exec( location.href );
        if ( match !== null ) {
            result = match[1];
        } else {
            result = '';
        }
        return result;
    }
    function createHiddenInputWithValue(appendToEl, inputName, inputValue){
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = inputName;
        input.value = inputValue;
        appendToEl.append(input);
    }
    const forms = document.querySelectorAll('form');
    forms.forEach((form)=> {
        console.log(form);
        //const div = form.querySelector('div');
        let userUniqDateTime = Date.now();
        createHiddenInputWithValue(form, "lm_source", window.location.href);
        createHiddenInputWithValue(form, "utm_source", getParamFromString(location.href, "utm_source"));
        createHiddenInputWithValue(form, "utm_medium", getParamFromString(location.href, "utm_medium"));
        createHiddenInputWithValue(form, "utm_campaign", getParamFromString(location.href, "utm_campaign"));
        createHiddenInputWithValue(form, "utm_term", getParamFromString(location.href, "utm_term"));
        createHiddenInputWithValue(form, "utm_content", getParamFromString(location.href, "utm_content"));
        createHiddenInputWithValue(form, "url", window.location.pathname);
        createHiddenInputWithValue(form, "device", window.innerWidth > 992 ? "Desktop" : "Mobile");
        createHiddenInputWithValue(form, "lm_serfer_ga_cid", userUniqDateTime);
        createHiddenInputWithValue(form, "creative", "calculator");
        createHiddenInputWithValue(form, "keyword", getParamFromString(location.href, "keyword"));
        createHiddenInputWithValue(form, "campaignID", getParamFromString(location.href, "campaignID"));
        createHiddenInputWithValue(form, "matchtype", getParamFromString(location.href, "matchtype"));
        createHiddenInputWithValue(form, "adgroupID", getParamFromString(location.href, "adgroupID"));
    });
    // for new leam.im end
});