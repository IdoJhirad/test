var leadUrl = 'https://lp.xnes.co.il/360/leads/backup_lead_guy_new.php'; //Staging
//var leadUrl = 'https://lp.xnes.co.il/xnes/leads/backup_lead.php'; //Live
var GA;//Google analytics id
function getParamFromString (link, name) {
	var result;
	var urlRegex = new RegExp(name + '=([^&]+)', 'm');
	var match = urlRegex.exec(link);
	if (match !== null) {
	  result = match[1];
	} else {
	  result = '';
	}

	return result;
}

jQuery(document).ready(function() {

jQuery.ajax({
        url: '/ajax.get.analytics.cookie.php',
        method: 'POST',
    })
    .done(function(data){
        GA = data;
    });

    /* --------- Mobile menu --------- */

    jQuery('.menu-toggle').click(function() {

        if (jQuery('.navigation').hasClass('visible')) {
            jQuery('.navigation').removeClass('visible');
        } else {
            jQuery('.navigation').addClass('visible');
        }

    });

    /* --------- Mobile menu --------- */



    /* --------- Accordion --------- */

    var allAccordions = jQuery('.accordion div.accordion-data');
    var allAccordionItems = jQuery('.accordion .accordion-item');
    jQuery('.accordion > .accordion-item').click(function() {
    if(jQuery(this).hasClass('open'))
        {
            jQuery(this).removeClass('open');
            jQuery(this).next().slideUp("slow");
        }
        else
        {
            allAccordions.slideUp("slow");
            allAccordionItems.removeClass('open');
            jQuery(this).addClass('open');
            jQuery(this).next().slideDown("slow");
            return false;
        }
    });

    /* --------- Accordion --------- */



    /* --------- Add a class "active" when you hover one of blog posts --------- */

    jQuery('.post-list .post').each(function() {

        jQuery(this).find('.post__button').hover(function() {
            if (jQuery(this).parent().hasClass('active')) {
                jQuery(this).parent().removeClass('active');
            } else {
                jQuery(this).parent().addClass('active');
            }
        });

        jQuery(this).find('.post__thumbnail').hover(function() {
            if (jQuery(this).parent().hasClass('active')) {
                jQuery(this).parent().removeClass('active');
            } else {
                jQuery(this).parent().addClass('active');
            }
        });

        jQuery(this).find('.post__title a').hover(function() {
            if (jQuery(this).parent().parent().hasClass('active')) {
                jQuery(this).parent().parent().removeClass('active');
            } else {
                jQuery(this).parent().parent().addClass('active');
            }
        });

    });

    /* --------- Add a class "active" when you hover one of blog posts --------- */



    /* --------- Zoom image --------- */

    var divOffset = $(".zoom").offset();

    $(".zoom").mousemove(function(event){

        var top = event.pageY - divOffset.top;
        var left = event.pageX - divOffset.left;

        $(".zoom .zoomed").css({
            "opacity" : "1",
            "top" : "-"+top+"px",
            "left" : "-"+left+"px"
        });

    }).mouseleave(function(){
        $(".zoom .zoomed").css("opacity","0");
    });

    /* --------- Zoom image --------- */

    var formSubmitted = false;

    jQuery('.iframe_form').submit(function(e){
        e.preventDefault();
        if (formSubmitted) return;
        formSubmitted = true;
        var data = {};
        data['campaignId'] = '5caaea01-f988-11ee-932f-0050560089df';
        data['lead'] = [];

        //data['lead'][0] = {"type":"full_name","name":"full_name","value":jQuery(this).find('[name=first_name]').val() + ' ' + jQuery(this).find('[name=second_name]').val()};
        data['lead'][0] = {"type":"full_name","name":"full_name","value":jQuery(this).find('[name=first_name]').val()};
        data['lead'][1] = {"type":"phone","name":"phone","value":jQuery(this).find('[name=phone]').val()};
        data['lead'][2] = {"type":"email","name":"email","value":jQuery(this).find('[name=email]').val()};

        data['media'] = jQuery(window).width() > 992 ? "Desktop" : "Mobile";
        // data['full_name'] = jQuery(this).find('[name=full_name]').val();
        // data['phone'] = jQuery(this).find('[name=phone]').val();
        // data['email'] = jQuery(this).find('[name=email]').val();
        //data['camp'] = 'xnes-iframe';
        data['camp'] = getParamFromString(location.href, "utm_campaign") ? getParamFromString(location.href, "utm_campaign") : "xnes-iframe";
        data['source'] = getParamFromString(location.href, "utm_source");
        data['subscribed'] = jQuery('#contactBlockCheckbox').is(':checked') ? '1' : '0';
        //New field added
        data['utm_source'] = getParamFromString(location.href, "utm_source");
        data['utm_campaign'] = getParamFromString(location.href, "campaign");
        //data['category'] = jQuery(this).find('[name=category]').val();
        data['category'] = 'מסחר עצמאי';            
        if(jQuery(this).find('input[type="checkbox"]').is(':checked')){
            data['newsletter'] = 1;
        }else{
            data['newsletter'] = 0;
        }
        data['leadUrl'] = window.location.protocol + '//' + window.location.host + window.location.pathname
        data['ga'] = GA;//You did this at Yaris campaign, same technique.
        data['gclid'] = getParamFromString(location.href, "gclid");
        data['term'] = getParamFromString(location.href, "term");
        data['content'] = getParamFromString(location.href, "content");
        data['utm_medium'] = getParamFromString(location.href, "utm_medium");

        /**
         * Post lead to new crm Lead.im
         */
        data["lm_source"] = window.location.href;
        data["lm_form"] = "86124";
        data["lm_key"] = "ac7209e6a9";
        data["utm_source"] = getParamFromString(location.href, "utm_source");
        data["utm_medium"] = getParamFromString(location.href, "utm_medium");
        data["utm_campaign"] = getParamFromString(location.href, "utm_campaign");
        data["utm_term"] = getParamFromString(location.href, "utm_term");
        data["utm_content"] = getParamFromString(location.href, "utm_content");
        data["url"] = window.location.pathname;
        data["device"] = window.innerWidth > 992 ? "Desktop" : "Mobile";
        data["lm_serfer_ga_cid"] = Date.now();

        data['keyword'] = getParamFromString(location.href, "keyword");
        data['campaignID'] = getParamFromString(location.href, "campaignID");
        data['matchtype'] = getParamFromString(location.href, "matchtype");
        data['adgroupID'] = getParamFromString(location.href, "adgroupID");

        jQuery.ajax({
            url: leadUrl,
            method: 'POST',
            data: JSON.stringify(data)
        })
        .done(function(){
            location.href = 'index_success.html' + window.location.search;
        });
    });
    if (getParamFromString(location.href, "super") != ''){
        var title;
        var untitle;
        title=getParamFromString(location.href, "super");
        untitle = decodeURIComponent(title);
        $('.orange-title').text(untitle)
    }
});

document.addEventListener("DOMContentLoaded", function(event) {
    // for new leam.im start
    function getParamFromString( link, name ) {
        let result;
        let urlRegex = new RegExp( name + '=([^&]+)', 'm' );
        let match = urlRegex.exec( location.href );
        if ( match !== null ) {
            result = match[1];
        } else {
            result = '';
        }
        return result;
    }
    function createHiddenInputWithValue(appendToEl, inputName, inputValue){
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = inputName;
        input.value = inputValue;
        appendToEl.append(input);
    }
    const forms = document.querySelectorAll('form');
    forms.forEach((form)=> {
        console.log(form);
        //const div = form.querySelector('div');
        let userUniqDateTime = Date.now();
        createHiddenInputWithValue(form, "lm_source", window.location.href);
        createHiddenInputWithValue(form, "utm_source", getParamFromString(location.href, "utm_source"));
        createHiddenInputWithValue(form, "utm_medium", getParamFromString(location.href, "utm_medium"));
        createHiddenInputWithValue(form, "utm_campaign", getParamFromString(location.href, "utm_campaign"));
        createHiddenInputWithValue(form, "utm_term", getParamFromString(location.href, "utm_term"));
        createHiddenInputWithValue(form, "utm_content", getParamFromString(location.href, "utm_content"));
        createHiddenInputWithValue(form, "url", window.location.pathname);
        createHiddenInputWithValue(form, "device", window.innerWidth > 992 ? "Desktop" : "Mobile");
        createHiddenInputWithValue(form, "lm_serfer_ga_cid", userUniqDateTime);
    });
    // for new leam.im end
});