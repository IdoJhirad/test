// JavaScript Document
function scrollToDiv(id)
{
  // Scroll
  $('html,body').animate({scrollTop: $("#"+id).offset().top},'slow');
}

function scrollToH(h)
{
  // Scroll
  $('html,body').animate({scrollTop: h + "px"},'slow');
}


var curQ = 1;

function ShowQ(view){
	$("#s"+curQ).hide();
	if(view){
		curQ++;
	}else{
		curQ--;
	}
	$("#s"+curQ).show();
}

var curQ1 = 0;
function Qstep1(id){
	if(curQ1 != 0){
		$("#pb"+curQ1).fadeOut(500);
	}
	$("#pb"+id).fadeIn(500);
	setTimeout(function(){
		curQ1 = id;
		
	},550)
	$("#btn2").show();
	$("#q1").val(id);
}

var curQ2 = 0;
function Qstep2(id){
	$(".clickOver").show();
	if(curQ2 != 0){
		$("#b3"+curQ2).css("border","2px solid #FFF");
	}
	$("#b3"+id).css("border","2px solid #FF5A23");
	curQ2 = id;
	setTimeout(function(){
		ShowQ(true);
		$(".clickOver").hide();
	},500)
	
	if(id == 1){
		$("#q2").val('1-3 שנים');
	}else if(id == 2){
		$("#q2").val('3-5 שנים');
	}else if(id == 3){
		$("#q2").val('5 שנים ומעלה');
	}
}

var curQ3 = 0;
function Qstep3(id){
	$(".clickOver").show();
	if(curQ3 != 0){
		$("#b4"+curQ3).css("border","2px solid #FFF");
	}
	$("#b4"+id).css("border","2px solid #FF5A23");
	curQ3 = id;
	setTimeout(function(){
		ShowQ(true);
		$(".clickOver").hide();
	},500)
	if(id == 1){
		$("#result1").show();
	}
	else if(id == 2){
		$("#result2").show();
	}
	else if(id == 3){
		$("#result3").show();
	}
	if(id == 1){
		$("#q3").val('כ-100,000 ₪');
	}else if(id == 2){
		$("#q3").val('100,000 ₪ - 1,000,000 ₪');
	}else if(id == 3){
		$("#q3").val('מעל 1 מיליון ₪');
	}
}

var curQ4 = 0;
function Qstep4(id){
	$(".clickOver").show();
	if(curQ4 != 0){
		$("#b5"+curQ4).css("border","2px solid #FFF");
	}
	$("#b5"+id).css("border","2px solid #FF5A23");
	curQ4 = id;
	setTimeout(function(){
		ShowQ(true);
		$(".clickOver").hide();
	},500)
	if(id == 1){
		$("#q4").val('לשמור על ערך הכסף');
	}else if(id == 2){
		$("#q4").val('לקבל תשואה כמו בבנק');
	}else if(id == 3){
		$("#q4").val('רוצה להכות את השוק');
	}
}



var curRes = 1;
var isPaging = false;
function ShowRes(dr){
	if(!isPaging){
		var newP = curRes;
		if(dr == 1 && curRes < 3){
			newP++;
			if(newP > 3){
				newP = 1;
			}
			TweenLite.to(".itemHolder", 0.5, {right: "-=320px", ease:Power2.easeIn});
		}else if(dr == 0  && curRes > 1){
			newP--;
			if(newP < 1){
				newP = 3;
			}
			TweenLite.to(".itemHolder", 0.5, {right: "+=320px", ease:Power2.easeIn});
	}
			$("#bul"+curRes).removeClass("bOn").addClass("bOff");
			$("#bul"+newP).removeClass("bOff").addClass("bOn");
			curRes = newP;
			isPaging = true;
		setTimeout(function(){
			isPaging = false;
		},550)
	}
}
/*
$(window).scroll(function() {
	var scrollPos = $(document).scrollTop();
	var isOverlay = collision($('#formHolder'), $('#stiky'));
    if (!isOverlay) {
		$("#stiky").show();
    } else {
		$("#stiky").hide();
    }

});


function collision($div1, $div2) {
      var x1 = $div1.offset().left;
      var y1 = $div1.offset().top;
      var h1 = $div1.outerHeight(true);
      var w1 = $div1.outerWidth(true);
      var b1 = y1 + h1;
      var r1 = x1 + w1;
      var x2 = $div2.offset().left;
      var y2 = $div2.offset().top;
      var h2 = $div2.outerHeight(true);
      var w2 = $div2.outerWidth(true);
      var b2 = y2 + h2;
      var r2 = x2 + w2;

      if (b1 < y2 || y1 > b2 || r1 < x2 || x1 > r2) return false;
      return true;
    }
*/



function ShowVideo(view){
	if(view){
		$("#VideoOverP").show();
		//$('#video').trigger('play');
		player.play();
	}else{
		$("#VideoOverP").hide();
		//$('#video').trigger('pause');
		player.pause();
	}
}