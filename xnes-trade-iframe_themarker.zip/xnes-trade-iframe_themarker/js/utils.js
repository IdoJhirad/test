// JavaScript Document

// copyright 1999 Idocs, Inc. http://www.idocs.com
// Distribute this script freely but keep this notice in place
function numbersonly(myfield, e, dec)
{
var key;
var keychar;

if (window.event)
   key = window.event.keyCode;
else if (e)
   key = e.which;
else
   return true;
keychar = String.fromCharCode(key);

// control keys
if ((key==null) || (key==0) || (key==8) || 
    (key==9) || (key==13) || (key==27) )
   return true;

// numbers
else if ((("0123456789").indexOf(keychar) > -1))
   return true;

// decimal point jump
else if (dec && (keychar == "."))
   {
   myfield.form.elements[dec].focus();
   return false;
   }
else
   return false;
}

function CheckAccept(){
		$('#errors').html('')
	var acc = Number($("#accept").val());
	if(acc == 0){
		$("#accept").val(1)
		document.getElementById("chb").setAttribute('src', "images/check_on.png");
		$('#errors').append('ההצהרה מסומנת');
	}else{
		$("#accept").val(0)
		document.getElementById("chb").setAttribute('src', "images/check_off.png");
		$('#errors').append('ההצהרה לא מסומנת');
	}
}



function showAlert()
{
	var erMess = document.getElementById("errors");
	erMess.innerHTML = " ";

}

function validID(str)
{ 
   //INPUT VALIDATION
   // Just in case -> convert to string
   var IDnum = String(str);

   // Validate correct input
   if ((IDnum.length > 9) || (IDnum.length < 5))
      return false; 
   if (isNaN(IDnum))
      return false;

   // The number is too short - add leading 0000
   if (IDnum.length < 9)
   {
      while(IDnum.length < 9)
      {
         IDnum = '0' + IDnum;         
      }
   }

   // CHECK THE ID NUMBER
   var mone = 0, incNum;
   for (var i=0; i < 9; i++)
   {
      incNum = Number(IDnum.charAt(i));
      incNum *= (i%2)+1;
      if (incNum > 9)
         incNum -= 9;
      mone += incNum;
   }
   if (mone%10 == 0)
      return true;
   else
      return false;
}


function validEmail(emailVar) {
	email = emailVar.toLowerCase();
	invalidChars = " /:,;";
	if (email == "") {
		return false;
	}
	for (i=0; i<invalidChars.length; i++) {
		badChar = invalidChars.charAt(i);
		if (email.indexOf(badChar, 0)>-1) {
			return false;
		}
	}
	atPos = email.indexOf("@", 1);
	if (atPos == -1) {
		return false;
	}
	if (email.indexOf("@", atPos+1) != -1) {
		return false;
	}
	periodPos = email.indexOf(".", atPos);
	if (periodPos == -1) {
		return false;
	}
	if (periodPos+3>email.length) {
		return false;
	}
	emailEnd_arr = [".nu",".com",".net",".org",".info",".biz",".name",".mobi",".cc",".ws",".co.il",".org.il",".muni.il",".net.il",".to",".eu",".at",".ac",".fm",".ro",".tc",".vg",".ms",".gs",".tv",".li",".io",".it",".jp",".nl",".ru",".co.uk",".com.mx",".co.nz",".net.nz",".org.nz",".sh",".tm",".gov.il"];
	for (i=0; i<=emailEnd_arr.length-1; i++)
	{
		index2 = email.indexOf(emailEnd_arr[i],atPos+2);
		if (Number(index2) != -1)
		{
			break;
		}
	}
	if (Number(index2) != -1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function EmailOnly(myfield, e){
	var charReg = /^\s*[a-zA-Z0-9@.\-\-_\s]+\s*$/;

var key;
var keychar;

if (window.event)
   key = window.event.keyCode;
else if (e)
   key = e.which;
else
   return true;
keychar = String.fromCharCode(key);

// control keys
if ((key==null) || (key==0) || (key==8) || 
    (key==9) || (key==13) || (key==27) )
   return true;

// numbers
else if (charReg.test(keychar))
   return true;

// decimal point jump
else
   return false;


}

function CheckString(st){
// Define the pattern using a regular expression
const pattern = /^[a-zA-Z א-ת]+$/;

// Test string against the pattern
const testString = st;
if (pattern.test(testString)) {
  console.log("String matches the pattern");
	return true;
} else {
  console.log("String does not match the pattern");
	return false;
}	
}


function HebNameOnly(myfield, e){
	var charReg = /^\s*[a-zA-Z א-ת\s]+\s*$/;

var key;
var keychar;

if (window.event)
   key = window.event.keyCode;
else if (e)
   key = e.which;
else
   return true;
keychar = String.fromCharCode(key);

// control keys
if ((key==null) || (key==0) || (key==8) || 
    (key==9) || (key==13) || (key==27) )
   return true;

// numbers
else if (charReg.test(keychar))
   return true;

// decimal point jump
else
   return false;


}

function ValidPhone(phone){
	if((phone.toString().substring(0,2) == "02" || phone.toString().substring(0,2) == "03" || phone.toString().substring(0,2) == "04" || phone.toString().substring(0,2) == "08" || phone.toString().substring(0,2) == "09") && phone.length != 9){
		return false;
	}
	if((phone.toString().substring(0,2) == "05" || phone.toString().substring(0,2) == "07") && phone.length != 10){
		return false;
	}
	if(phone.toString().substring(0,2) != "02" && phone.toString().substring(0,2) != "03" && phone.toString().substring(0,2) != "04" && phone.toString().substring(0,2) != "08" && phone.toString().substring(0,2) != "09" && phone.toString().substring(0,3) != "050" && phone.toString().substring(0,3) != "051" && phone.toString().substring(0,3) != "052" && phone.toString().substring(0,3) != "053" && phone.toString().substring(0,3) != "054" && phone.toString().substring(0,3) != "055" && phone.toString().substring(0,3) != "056" && phone.toString().substring(0,3) != "057" && phone.toString().substring(0,3) != "058" && phone.toString().substring(0,3) != "059" && phone.toString().substring(0,3) != "072" && phone.toString().substring(0,3) != "073" && phone.toString().substring(0,3) != "074" && phone.toString().substring(0,3) != "077" && phone.toString().substring(0,3) != "078"){
		return false;
	}
	if(phone.toString().substring(0,1) != "0" || phone.toString().substring(0,1) == "1"){
		return false;
	}
	else{
		return true;		
	}
}

function SubmitData(){
	$('#ErrorDiv').html('');
	valid = true;
	var full_name = $("#full_name").val();
	var phone = $("#phone").val();
	var email = $("#email").val();
	var accept = $("#iframe_checkbox").val();
	$("#full_name").css("border", "2px solid #FFF");
	$("#phone").css("border", "2px solid #FFF");
	$("#email").css("border", "2px solid #FFF");
console.log("accept=" + accept);
	
	//if(full_name.length < 2 || full_name.indexOf(' ') == -1){
	if(full_name.length < 2){
		$("#full_name").focus();
		$("#full_name").css("border", "2px solid #F00");
		//$('#ErrorDiv').append('אנא הקלד שם מלא');
		valid = false;
	}
	else if(!CheckString(full_name)){
		$("#full_name").focus();
		$("#full_name").css("border", "2px solid #F00");
		//$('#ErrorDiv').append('ניתן להקליד בעברית או אנגלית בלבד');
		valid = false;
	}
	else if (!ValidPhone(phone)){
		$("#phone").focus()
		$("#phone").css("border", "2px solid #F00");
		//$('#ErrorDiv').append('מספר טלפון שגוי');
		valid = false;
	}
	  else if (!validEmail(email)) {
		$("#email").focus();
		$("#email").css("border", "2px solid #F00");
		//$('#ErrorDiv').append('כתובת אימייל שגויה');
		valid = false;
	  } 
	else if(valid){
			$("#FormDiv").fadeOut(500);
			$("#ThanksDiv").fadeIn(500);
			$("#ContactForm").submit();
	}
}
function CloseForm(id){
		$("#FormDiv").fadeIn(500);
		$("#ThanksDiv").fadeOut(500);
}

