<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 0);
//error_reporting(E_ALL);

$ver = rand(10000, 15000);
?>

<!doctype html>
<html>
<head>
    <meta name="robots" content="noindex">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="format-detection" content="address=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>XNES Iframe</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="fonts/stylesheet.css">
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5LJNLWQ');</script>
<!-- End Google Tag Manager -->
<script type="text/javascript" language="javascript" src="js/utils.js?ver=<?php echo $ver; ?>"></script>

</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5LJNLWQ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="site">
	<div class="xnes_iframe">
        <div class="iframe_content">
            <div class="iframe_top">
                <img src="img/Logo.png" alt="">
            </div>
             <div class="iframe_bottom" id="ThanksDiv" style="display: none;">
                	<p class="orange-title"><strong>פרטיך התקבלו בהצלחה!</strong></p>
            </div>
           <div class="iframe_bottom" id="FormDiv">
                <div class="iframe_title">
                	<p class="orange-title">רוצים שמנהל השקעות מקצועי יחזור אליכם?</p>
                	<span>השאירו פרטים</span>
                </div>
			<form id="ContactForm" name="ContactForm" class="iframe_form" method="post" action="https://lp.xnes.co.il/360/leads/backup_lead_guy_new.php" target="sendDetails">					
 <input type="hidden" name="campaignId" value="5caaea01-f988-11ee-932f-0050560089df">
<input type="hidden" name="lm_form" value="86124">
<input type="hidden" name="lm_key" value="ac7209e6a9">
<input type="hidden" name="CampaignNumber" value="">
<input type="hidden" name="IntegrationId" value="">
<input type="hidden" name="creative" value="themarker_iframe">
<input type="hidden" name="device" value="<?php echo $device; ?>">
<input type="hidden" name="leadUrl" value="<?php echo $leadUrl; ?>">
<input type="hidden" name="mailmore" value="<?php echo $agEmail; ?>">
<input type="hidden" name="utm_source" value="themarker">
<input type="hidden" name="utm_campaign" value="article_themarker_portfoliomanagement_protect_2024">
<input type="hidden" name="utm_medium" value="iframe_lead_form">
<input type="hidden" name="utm_term" value="<?php echo $_REQUEST['utm_term']; ?>">
<input type="hidden" name="utm_content" value="<?php echo $_REQUEST['utm_content']; ?>">
<input type="hidden" name="ga" value="<?php echo $_REQUEST['ga']; ?>">
<input type="hidden" name="gclid" value="<?php echo $_REQUEST['gclid']; ?>">
<input type="hidden" name="lm_serfer_ga_cid" value="<?php echo date("Y-m-d H:i:s"); ?>">
<input type="hidden" name="keyword" value="<?php echo $_REQUEST['keyword']; ?>">
<input type="hidden" name="matchtype" value="<?php echo $_REQUEST['matchtype']; ?>">
<input type="hidden" name="adgroupID" value="<?php echo $_REQUEST['adgroupID']; ?>">
				
                   <div class="iframe_form_columns">
                        <p>
                            <input name="full_name" id="full_name" placeholder="שם מלא" type="text" required oninvalid="this.setCustomValidity('יש להקליד שם מלא')" oninput="this.setCustomValidity('')">
                        </p>
                        <p>
                            <input name="phone" id="phone" placeholder="טלפון" type="tel" maxlength="10" pattern="[0-9]{9,10}" required oninvalid="this.setCustomValidity('יש להקליד מספר טלפון')" oninput="this.setCustomValidity('')">
                        </p>
                        <p>
                            <input name="email" id="email" placeholder="אימייל" type="email" required oninvalid="this.setCustomValidity('יש להקליד כתובת מייל תקנית')" oninput="this.setCustomValidity('')">
                        </p>
                    </div>
                    <p class="extra">
                        <input type="checkbox" name="accept" id="accept" checked>
                        <label for="accept">הנני מאשר/ת קבלת מידע נוסף וחומר פרסומי</label>
                    </p>
                    <p>
                        <input type="button" onClick="SubmitData()" value="צרו איתי קשר">
                    </p>
                </form>
            </div>
            <div class="iframe_text">
                 <a href="https://www.xnes.co.il/media/6567/riskmanagementprotect.pdf" target="_blank"><span>גילוי נאות</span></a>
            </div>
	    </div>
	</div>
</div>
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/easing.1.3.js"></script>
<iframe frameborder="0" height="0" width="0" name="sendDetails" id="sendDetails" marginheight="0" marginwidth="0" src=""></iframe>
<iframe frameborder="0" height="0" width="0" name="sendDetails2" id="sendDetails2" marginheight="0" marginwidth="0" src=""></iframe>


</body>
</html>